import torch
import numpy as np
import matplotlib.pyplot as plt
from models.cgru import cGRU, train_model_ista
from scipy.integrate import odeint
from sklearn.preprocessing import MinMaxScaler
from gan import train_AE


print("开始!")
# For GPU acceleration
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
import os
# 获取数据
def get_all_file_paths(directory):
    file_paths = []
    # 遍历文件夹
    for root, _, files in os.walk(directory):
        for file in files:
            # 获取文件完整路径
            file_path = os.path.join(root, file)
            file_paths.append(file_path)
    return file_paths

import datetime


def to_shape(data):
        # 转换为[1,1000,10]
        data = np.array(data)
        data = data.T
        data = data.reshape(1,130,17)
    
        return data



def time_print(msg, *args):
    print(f"[{str(datetime.datetime.now())}] {str(msg)}", *args)

# 示例：获取指定文件夹内所有文件的路径
directory = './data/CN_MAT'   # 将此路径替换为你的目标文件夹路径
file_paths = get_all_file_paths(directory)
print(file_paths)

from scipy.io import loadmat
X_list = []
time_print('数据读取!')
for iter in range(len(file_paths)):
    
    X = loadmat(file_paths[iter])['voxel_time_series_all']
    X_list.append(X)

from sklearn.preprocessing import StandardScaler

label = 1
for X in X_list:
    encode_data_list_ = []
    time_print(f"第{label}份数据 ")
    try:
        time_print('编码开始!')
        mean_data = [np.mean(X_[0], axis=0) for X_ in X]
        encode_data_array = np.array(mean_data).reshape(17, 140)[:, 10:]
        time_print('标准化处理!')
        # 创建一个标准化后的数据数组
        normalized_data = np.zeros_like(encode_data_array)
        
        # 对每个节点的时间序列数据进行标准化
        for i in range(encode_data_array.shape[0]):
            scaler = StandardScaler()
            normalized_data[i, :] = scaler.fit_transform(encode_data_array[i, :].reshape(-1, 1)).flatten()
        
        encode_data_array = to_shape(normalized_data)
        X_tensor = torch.tensor(encode_data_array, dtype=torch.float32, device=device)
        time_print('训练开始')
        clstm = cGRU(X_tensor.shape[-1], hidden=128).to(device=device)
        time_print(f'cLSTM的{label}次迭代开始！')
        # Train with ISTA
        train_loss_list = train_model_ista(
            clstm, X_tensor, context=10, lam=0.05, lam_ridge=1e-3, lr=2e-3, max_iter=15000,
            check_every=2500)
        GC_est = clstm.GC(threshold=False).cpu().data.numpy()
        
        path = file_paths[label-1]
        path_list = path.split('/')
        name = path_list[-1].split('.')[0]
        path = '/'.join(path_list[3:])
        path = '/'.join(path.split('/')[:-1])
        path = "./out_cn_gru/"+path
        if not os.path.exists(path):
            os.makedirs(path)
        name += ".npy"
        path = path+'/'+name
        np.save(path, GC_est)
    except:
        time_print(str(label)+" Error！")
    label+=1